export const GET_ALL_COMMENTS = "getAllCommentsfun";
export const PLACE_NEW_COMMENT = "postnewCommentsfun";
export const UPDATE_COMMENT = "updateCommentsfun";

export const ERROR_GET_ALL_COMMENTS = "errorgetAllCommentsfun";
export const ERROR_PLACE_NEW_COMMENT = "errorpostnewCommentsfun";
export const ERROR_UPDATE_COMMENT = "errorupdateCommentsfun";
