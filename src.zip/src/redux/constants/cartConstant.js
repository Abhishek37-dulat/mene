export const GET_CART = "getcartfun";
export const ADD_CART = "getaddcartfun";
export const DELETE_CART = "deletecartfun";
export const REMOVE_CART = "removefun";
export const SEARCH_ITEM = "searchitemfun";
export const INCREASE_CART = "increasecartfun";
export const DEC_CART = "deccartfun";
export const EMPTY_CART = "emptycartfun";

export const ERROR_GET_CART = "errorgetcartfun";
export const ERROR_ADD_CART = "errorgetaddcartfun";
export const ERROR_DELETE_CART = "errordeletecartfun";
export const ERROR_REMOVE_CART = "errorremovecartfun";
export const ERROR_SEARCH_ITEM = "errorsearchitemfun";
export const ERROR_INCREASE_CART = "errorincreasecartfun";
export const ERROR_DEC_CART = "errordeccartfun";
export const ERROR_EMPTY_CART = "erroremptycartfun";
