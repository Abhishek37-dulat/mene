export const GET_PROFILE = "getProfilefun";
export const ADD_PROFILE = "addProfilefun";
export const UPDATE_PROFILE = "updateProfilefun";

export const ERROR_GET_PROFILE = "errorgetProfilefun";
export const ERROR_ADD_PROFILE = "erroraddProfilefun";
export const ERROR_UPDATE_PROFILE = "errorupdateProfilefun";
