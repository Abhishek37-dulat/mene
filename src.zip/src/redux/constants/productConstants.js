export const GET_ALL_PRODUCTS = "getAllProductsfun";
export const GET_SINGLE_PRODUCT = "getSingleProductfun";

export const ERROR_GET_ALL_PRODUCTS = "errorgetAllProductsfun";
export const ERROR_GET_SINGLE_PRODUCT = "errorgetSingleProductfun";
