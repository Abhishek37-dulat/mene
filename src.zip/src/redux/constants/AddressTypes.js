export const USER_ADDRESS = "getUserAddressfun";
export const UPDATE_USER_ADDRESS = "getUpdateUserAddressfun";
export const ADD_USER_ADDRESS = "getAddUserAddressfun";
export const DELETE_USER_ADDRESS = "getDeleteUserAddressfun";

export const ERROR_USER_ADDRESS = "errorgetUserAddressfun";
export const ERROR_UPDATE_USER_ADDRESS = "errorgetUpdateUserAddressfun";
export const ERROR_ADD_USER_ADDRESS = "errorgetAddUserAddressfun";
export const ERROR_DELETE_USER_ADDRESS = "errorgetDeleteUserAddressfun";
