export const GET_ALL_POSTS = "getAllPostfun";

export const ERROR_GET_ALL_POSTS = "errorgetAllPostfun";
