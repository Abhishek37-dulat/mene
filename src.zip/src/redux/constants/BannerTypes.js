export const GET_ALL_BANNER = "getAllBannerfun";

export const ERROR_GET_ALL_BANNER = "errorgetAllBannerfun";
