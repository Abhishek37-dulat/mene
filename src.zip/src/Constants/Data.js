import Sgirl1 from "../images/imgpsh_fullsize_anim (1).png";
import Sgirl2 from "../images/imgpsh_fullsize_anim (2).png";
import Sgirl3 from "../images/imgpsh_fullsize_anim.png";

export const imageURL = [
  {
    id: 1,
    Img: Sgirl1,
    category: "hair-toppers",
    url: "hair-toppers",
    Text: "Hair Topper",
  },
  {
    id: 2,
    Img: Sgirl2,
    category: "all-things-hair",
    url: "all-things-hair",
    Text: "All Things Hair",
  },
  {
    id: 3,
    Img: Sgirl3,
    category: "strandouts",
    url: "strandouts",
    Text: "Strandouts",
  },
  {
    id: 4,
    Img: Sgirl1,
    category: "clip-in-bangs",
    url: "clip-in-bangs",
    Text: "Clip In Bangs",
  },
  {
    id: 5,
    Img: Sgirl2,
    category: "wigs",
    url: "wigs",
    Text: "Wigs",
  },
  {
    id: 6,
    Img: Sgirl3,
    category: "hair-extension",
    url: "hair-extension",
    Text: "Hair Extension",
  },
  {
    id: 7,
    Img: Sgirl2,
    category: "accessories",
    url: "accessories",
    Text: "Accessories",
  },
  {
    id: 8,
    Img: Sgirl1,
    category: "halo-hair",
    url: "halo-hair",
    Text: "Halo Hair",
  },
];
