export const StepVideoData = [
  {
    id: 1,
    step: "step 1",
    embedId: "C-eTdH2UPXI?si=IZo83096g-Y9ANLj",
    text: "How to Wear Hair",
    desc: "learn how to wear hair",
  },
  {
    id: 2,
    step: "step 2",
    embedId: "C-eTdH2UPXI?si=IZo83096g-Y9ANLj",
    text: "How to Remove Hair",
    desc: "learn how to remove hair",
  },
  {
    id: 3,
    step: "step 3",
    embedId: "XTcRgD1kPHQ?si=ppmpz574ZGWixNf8",
    text: "How to Wash Hair",
    desc: "learn how to wash hair",
  },
];
