export const colors = [
  {
    id: 1,
    name: "Dark Black",
    value: "#000",
  },
  {
    id: 2,
    name: "Natural Black",
    value: "#454545",
  },
  {
    id: 3,
    name: "Dark Brown",
    value: "#654321",
  },
  {
    id: 4,
    name: "Light Brown",
    value: "#B5651D",
  },
  {
    id: 5,
    name: "Natural Black with highlights",
    value: "grey",
  },
  {
    id: 6,
    name: "Parul's Ombre",
    value: "white",
  },
];
