import React from "react";

const PaymentVerify = () => {
  return <div>paymentverification</div>;
};

export default PaymentVerify;
