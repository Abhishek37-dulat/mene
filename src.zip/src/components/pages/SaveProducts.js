import React from "react";

const SaveProducts = () => {
  return (
    <>
      <div>save products Data</div>
    </>
  );
};

export default SaveProducts;
